"use strict";

class Empleado {
    #nombre;
    #apellidos;
    #nacimiento;
    #sueldo;
    #dni;
    #email;

    constructor(nombre, apellidos, nacimiento, sueldo, dni, email) {
        this.#nombre = nombre;
        this.#apellidos = apellidos;
        this.#nacimiento = nacimiento;
        this.#sueldo = sueldo;
        this.#dni = dni;
        this.#email = email;
    }

    render() {
        let fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${this.#nombre}</td>
            <td>${this.#apellidos}</td>
            <td>${this.#nacimiento}</td>
            <td>${this.#sueldo}</td>
            <td>${this.#dni}</td>
            <td>${this.#email}</td>
        `;
        return fila;
    }
}

// Crear formulario
const formulario = document.createElement("form");
formulario.id = "form-empleados";
formulario.innerHTML = `
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre" placeholder="Introduce el nombre"><br>

    <label for="apellidos">Apellidos:</label>
    <input type="text" name="apellidos" id="apellidos" placeholder="Introduce los apellidos"><br>

    <label for="nacimiento">Año de nacimiento:</label>
    <input type="text" name="nacimiento" id="nacimiento" placeholder="1990"><br>

    <label for="sueldo">Sueldo:</label>
    <input type="text" name="sueldo" id="sueldo" value="3000"><br>

    <label for="dni">DNI:</label>
    <input type="text" name="dni" id="dni" placeholder="12345678A"><br>

    <label for="email">Email:</label>
    <input type="text" name="email" id="email" placeholder="correo@ejemplo.com"><br>

    <button type="button" id="boton-enviar">Enviar</button>
`;
document.body.appendChild(formulario);

// Crear tabla(Por si acaso luego lo mandase)
const tabla = document.createElement("table");
tabla.innerHTML = `
    <thead>
        <tr>
            <th onclick="ordenaNombre()">Nombre</th>
            <th onclick="ordenaApellidos()">Apellidos</th>
            <th onclick="ordenaAnno()">Año nacimiento</th>
            <th onclick="ordenaSueldo()">Sueldo</th>
            <th>DNI</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody id="lista-empleados">
    </tbody>
`;
document.body.appendChild(tabla);

let empleados = [
    new Empleado("Paco", "Fiestas", 1997, 27000, "71954030W", "paco.fiestas@example.com"),
    new Empleado("Elsa", "Polindo", 1994, 4500, "71954030A", "elsa.polindo@example.com"),
    new Empleado("Misty", "Peres", "12345678S", 1772, 2000, "misty@gmail.com"),
    new Empleado("Joan", "Laporta", "12345678S", 1991, 1000, "barcelona@gmail.com"),
    new Empleado("Sabrina", "Carpenter", "12345678S", 1987, 26000, "sabrina@gmail.com"),
    new Empleado("Eulalio", "Fernandez", "12345678S", 1999, 50000, "fernandez@gmail.com"),
];

let listaEmpleados = document.getElementById("lista-empleados");
empleados.forEach(empleado => listaEmpleados.appendChild(empleado.render()));

const campos = ["nombre", "apellidos", "nacimiento", "sueldo", "dni", "email"];
campos.forEach(campo => {

    document.getElementById(campo).addEventListener("blur", function () {
        let valor = this.value.trim();

        if (!valor) {
            this.style.border = "2px solid red";
            return;
        }
        if (campo === "nacimiento" && !validarFecha(valor)) {
            this.style.border = "2px solid red";
            return;
        }
        if (campo === "dni" && !validarDNI(valor)) {
            this.style.border = "2px solid red";
            return;
        }
        if (campo === "email" && !validarEmail(valor)) {
            this.style.border = "2px solid red";
            return;
        }
        this.style.border = "2px solid green";
    });
});

document.getElementById("boton-enviar").addEventListener("click", function () {
    const camposInvalidos = campos.filter(campo => {
        const input = document.getElementById(campo);
        return input.style.border !== "2px solid green";
    });

    if (camposInvalidos.length > 0) {
        alert("Si faltan campos no puedes enviarlo.");
        return;
    }

    meterEmpleado();
});

function meterEmpleado() {
    let [nombre, apellidos, nacimiento, sueldo, dni, email] = campos.map(campo =>
        //trim elimina los espacios innecesarios
        document.getElementById(campo).value.trim()
    );

    let empleado = new Empleado(nombre, apellidos, nacimiento, sueldo, dni, email);
    empleados.push(empleado);
    listaEmpleados.appendChild(empleado.render());
}

function validarDNI(dni) {
    const letras = "TRWAGMYFPDXBNJZSQVHLCKE";
    if (!/^\d{8}[A-Z]$/.test(dni)) return false;
    const numero = parseInt(dni.slice(0, -1), 10);
    const letra = dni.slice(-1);
    return letras[numero % 23] === letra;
}

function validarEmail(email) {
    const partes = email.split("@");
    if (partes.length !== 2 || !partes[1].includes(".")) return false;
    return !partes[1].startsWith(".") && !partes[1].endsWith(".");
}

function validarFecha(fecha) {
    const fechaReg = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const match = fecha.match(fechaReg);
    if (!match) 
        return false;

    const dia = parseInt(match[1], 10);
    const mes = parseInt(match[2], 10);
    const anio = parseInt(match[3], 10);

    if (mes < 1 || mes > 12 || dia < 1 || dia > 31) 
        return false;

    const diasCadaMes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if ((anio % 4 === 0 && anio % 100 !== 0) || anio % 400 === 0) {
        diasCadaMes[1] = 29;
    }

    return dia <= diasCadaMes[mes - 1];
}